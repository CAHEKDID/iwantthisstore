<?php
//include $_SERVER["DOCUMENT_ROOT"] . "templates/bootstrap.php";

include $_SERVER["DOCUMENT_ROOT"] . "pages/view/services.view.php";
