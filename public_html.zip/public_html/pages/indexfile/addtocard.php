<?php
//$product[$_POST['id']]=$_POST['sizes'];
//$product['id']=$_POST['id'];
//    $product['sizes']=$_POST['sizes'];
//$images = $dataProds ->getImgProd($product);

include $_SERVER["DOCUMENT_ROOT"] . '/pages/indexfile/view.basket.php';
