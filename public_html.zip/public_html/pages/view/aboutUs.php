<?php include $_SERVER["DOCUMENT_ROOT"] . "/templates/header.php" ?>
<!--<div class="aboutus">-->
<!--<div class="backimg">-->

<!---->
<!---->
<!--    <p class="txtUs">-->
<!--        Мы создаём одежду и не только с уникальным дизайном, который разработан самим исполнителем!-->
<!--        <br>-->
<!--        Вы слушаете, а мы делаем ,чтобы вы еще и носили!!!-->
<!--    </p>-->
<!--    <p class="ps">С любовью, CAHEKDID</p>-->
<!--</div>-->
<!--</div>-->
<div class="discr">
        <img src="/img/ABOUTUS.png" class="picus">
<!--    <p class="txtUs">-->
<!--                Мы создаём одежду и не только с уникальным дизайном, который разработан самим исполнителем!-->
<!--                <br>-->
<!---->
<!--            </p>-->
<!--    <p class="txtUs1"> Вы слушаете, а мы делаем ,чтобы вы еще и носили!!!</p>-->

</div>
<?php include $_SERVER["DOCUMENT_ROOT"] . "/templates/footer.php" ?>
