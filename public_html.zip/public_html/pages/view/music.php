<?php include $_SERVER["DOCUMENT_ROOT"] . "/templates/header.php" ?>


<div class="music">
    <div class="d1"><a href=""><img src="/img/suc/01.jpg"></a></div>
    <div class="d2"><a href=""><img src="/img/suc/02.jpg"></a></div>
    <div class="d3"><a href=""><img src="/img/suc/03.jpg"></a></div>
    <div class="d4"><a href=""><img src="/img/suc/04.jpg"></a></div>
    <div class="d5"><a href=""><img src="/img/suc/05.jpg"></a></div>
    <div class="d6"><a href=""><img src="/img/suc/06.jpg"></a></div>
</div>

