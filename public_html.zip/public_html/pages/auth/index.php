<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'].'/pages/auth/auth.view.php';


