<footer>
    <a rel="nofollow" href="https://vk.com/cahekdidmusicformyheart"><img src="/img/vk.png" class="foots"></a>
    <a rel="nofollow" href="https://www.instagram.com/_cahekdid_/"><img src="/img/instagram.png" class="foots"></a>
    <a rel="nofollow" href="https://music.apple.com/ru/artist/cahekdid/id1509998859"><img class="foots" src="/img/am.png"></a>
    <a rel="nofollow" href="https://open.spotify.com/artist/2rwsE1c59Tnb8L2fiTzBCI"><img class="foots" src="/img/spotify.png"></a>
</footer>
<script
        src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
        crossorigin="anonymous"></script>
<script>

    $(function(){
        $("#phone").mask("8(999) 999-9999");
    });
</script>
</body>

</html>